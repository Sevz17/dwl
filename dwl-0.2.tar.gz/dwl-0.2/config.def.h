/* appearance */
static const int sloppyfocus        = 1;  /* focus follows mouse */
static const unsigned int borderpx  = 2;  /* border pixel of windows */
static const float rootcolor[]      = {0.3, 0.3, 0.3, 1.0};
static const float focuscolor[]    = {0.4, 0.0, 1.0, 1.0};
static const float bordercolor[]     = {0.0, 0.0, 0.0, 0.7};

/* tagging */
static const char *tags[] = { " ", "﬏ ", " ", " ", " ", " ", " ", " ", " ", " " };

static const Rule rules[] = {
	/* app_id     title       tags mask     isfloating   monitor */
	/* examples:
	{ "Gimp",     NULL,       0,            1,           -1 },
	{ "firefox",  NULL,       1 << 8,       0,           -1 },
	*/
};

/* layout(s) */
static const Layout layouts[] = {
	/* symbol     arrange function */
	{ "[]=",      tile },
	{ "><>",      NULL },    /* no layout function means floating behavior */
	{ "[M]",      monocle },
	{ NULL,       NULL },
};

/* monitors
 * The order in which monitors are defined determines their position.
 * Non-configured monitors are always added to the left. */
static const MonitorRule monrules[] = {
	/* name       mfact nmaster scale layout       rotate/reflect x y */
	/* example of a HiDPI laptop monitor:
	{ "eDP-1",    0.5,  1,      2,    &layouts[0], WL_OUTPUT_TRANSFORM_NORMAL, 0, 0 },
	*/
	/* defaults */
	{ NULL,       0.50, 1,      1,    &layouts[2], WL_OUTPUT_TRANSFORM_NORMAL, 0, 0 },
};

/* keyboard */
static const struct xkb_rule_names xkb_rules = {
	/* can specify fields: rules, model, layout, variant, options */
	/* example:
	.options = "ctrl:nocaps",
	*/
	.layout  = "latam,latam,us",
	.model   = "pc105",
	.variant = "dvorak,,",
	.options = "grp:win_space_toggle , keypad:pointerkeys , terminate:ctrl_alt_bksp",
};

/* numlock and capslock */
static const int numlock = 1;
static const int capslock = 0;

static const int repeat_rate = 25;
static const int repeat_delay = 600;

/* Time (in miliseconds) until the cursor will hidde */
static const int cursor_inactive = 1000;

/* Disable acceleration */
static const int disable_mouse_acceleration = 1;

/* Trackpad */
static const int tap_to_click = 1;
static const int natural_scrolling = 0;

#define MODKEY WLR_MODIFIER_LOGO
#define ALTKEY WLR_MODIFIER_ALT
#define Control WLR_MODIFIER_CTRL
#define Shift WLR_MODIFIER_SHIFT

#define TAGKEYS(KEY,SKEY,TAG) \
	{ MODKEY,                    KEY,            view,            {.ui = 1 << TAG} }, \
	{ MODKEY|WLR_MODIFIER_CTRL,  KEY,            toggleview,      {.ui = 1 << TAG} }, \
	{ MODKEY|WLR_MODIFIER_SHIFT, SKEY,           tag,             {.ui = 1 << TAG} }, \
	{ MODKEY|WLR_MODIFIER_CTRL|WLR_MODIFIER_SHIFT,SKEY,toggletag, {.ui = 1 << TAG} }

/* helper for spawning shell commands in the pre dwm-5.0 fashion */
#define SHCMD(cmd) { .v = (const char*[]){ "/bin/sh", "-c", cmd, NULL } }

/* commands */
static const char *termcmd[] = { "alacritty", NULL };
static const char *menucmd[] = { "bemenu-run", NULL };

static const Key keys[] = {
	/* Note that Shift changes certain key codes: c -> C, 2 -> at, etc. */
	/* modifier                  key                 function        argument */

    /* ------------------ Windows ------------------ */

	/* Switch between windows */
	{ MODKEY,                    XKB_KEY_r,          focusstack,     {.i = +1} },
	{ MODKEY,                    XKB_KEY_t,          focusstack,     {.i = -1} },

	/* Change window sizes */
	{ MODKEY,                    XKB_KEY_c,          incnmaster,     {.i = +1} },
	{ MODKEY|Shift,              XKB_KEY_C,          incnmaster,     {.i = -1} },
	{ MODKEY,                    XKB_KEY_d,          setmfact,       {.f = -0.05} },
	{ MODKEY,                    XKB_KEY_n,          setmfact,       {.f = +0.05} },

	/* Toggle floating */
	{ MODKEY|Control,            XKB_KEY_u,          togglefloating, {0} },

	/* Toggle fullscreen */
	{ MODKEY|Shift,              XKB_KEY_U,          togglefullscreen, {0} },

	/* Cycle layouts */
	{ MODKEY,                    XKB_KEY_Tab,        cyclelayout,    {.i = +1 } },
	{ MODKEY|Shift,              XKB_KEY_Tab,        cyclelayout,    {.i = -1 } },

	/* Focus next - prev monitor */
	{ MODKEY,                    XKB_KEY_w,          focusmon,       {.i = WLR_DIRECTION_LEFT} },
	{ MODKEY,                    XKB_KEY_v,          focusmon,       {.i = WLR_DIRECTION_RIGHT} },

	/* Send window to next - prev monitor */
	{ MODKEY|Shift,              XKB_KEY_W,          tagmon,         {.i = WLR_DIRECTION_LEFT} },
	{ MODKEY|Shift,              XKB_KEY_V,          tagmon,         {.i = WLR_DIRECTION_RIGHT} },

	/* Kill window */
	{ MODKEY,                    XKB_KEY_comma,      killclient,     {0} },

	/* Quit dwl */
	{ MODKEY|Control,            XKB_KEY_period,     quit,           {0} },

//	/* Restart dwl */
//	{ MODKEY|Control,            XKB_KEY_p,          quit,           {1} },

    /* Shutdown computer */
    { ALTKEY|Control,            XKB_KEY_Delete,     spawn,          SHCMD("shutdown now") },

    /* Restart computer */
    { ALTKEY|Control,            XKB_KEY_Insert,     spawn,          SHCMD("reboot") },

    /* Hibernate computer */
    { MODKEY|Control,            XKB_KEY_Delete,     spawn,          SHCMD("systemctl hibernate") },

    /* Suspend computer */
    { MODKEY|Control,            XKB_KEY_Insert,     spawn,          SHCMD("systemctl suspend") },

	
    /* ---------------- Workspaces ----------------- */
	TAGKEYS(          XKB_KEY_1, XKB_KEY_exclam,                     0),
	TAGKEYS(          XKB_KEY_2, XKB_KEY_quotedbl,                   1),
	TAGKEYS(          XKB_KEY_3, XKB_KEY_numbersign,                 2),
	TAGKEYS(          XKB_KEY_4, XKB_KEY_dollar,                     3),
	TAGKEYS(          XKB_KEY_5, XKB_KEY_percent,                    4),
	TAGKEYS(          XKB_KEY_6, XKB_KEY_ampersand,                  5),
	TAGKEYS(          XKB_KEY_7, XKB_KEY_slash,                      6),
	TAGKEYS(          XKB_KEY_8, XKB_KEY_parenleft,                  7),
	TAGKEYS(          XKB_KEY_9, XKB_KEY_parenright,                 8),
	TAGKEYS(          XKB_KEY_0, XKB_KEY_equal,                      9),

	/* Switch between the last tag and the current */
	{ MODKEY,                    XKB_KEY_z,          view,           {0} },

    /* ------------------- Apps -------------------- */

	{ MODKEY,                    XKB_KEY_Menu,       spawn,          {.v = menucmd} },

	/* wofi */
	{ MODKEY,                    XKB_KEY_m,          spawn,          SHCMD("wofi --show=drun") },

	/* Terminal emulators */
	{ MODKEY,                    XKB_KEY_Return,     spawn,          {.v = termcmd} },
//	{ MODKEY,                    XKB_KEY_Return,     zoom,           {0} },
//	{ MODKEY|WLR_MODIFIER_SHIFT, XKB_KEY_parenright, tag,            {.ui = ~0} },

    /* ----------------- Hardware ------------------ */

    /* Volume */
    {MODKEY,                     XKB_KEY_apostrophe, spawn,          SHCMD("pactl set-sink-volume @DEFAULT_SINK@ -2%")},
    {MODKEY,                     XKB_KEY_questiondown,spawn,         SHCMD("pactl set-sink-volume @DEFAULT_SINK@ +2%")},
    {MODKEY,                     XKB_KEY_BackSpace,  spawn,          SHCMD("pactl set-sink-mute @DEFAULT_SINK@ toggle")},


	/* Ctrl-Alt-Backspace and Ctrl-Alt-Fx used to be handled by X server */
	{ WLR_MODIFIER_CTRL|WLR_MODIFIER_ALT,XKB_KEY_Terminate_Server, quit, {0} },
#define CHVT(n) { WLR_MODIFIER_CTRL|WLR_MODIFIER_ALT,XKB_KEY_XF86Switch_VT_##n, chvt, {.ui = (n)} }
	CHVT(1), CHVT(2), CHVT(3), CHVT(4), CHVT(5), CHVT(6),
	CHVT(7), CHVT(8), CHVT(9), CHVT(10), CHVT(11), CHVT(12),
};

static const Button buttons[] = {
	{ MODKEY, BTN_LEFT,   moveresize,     {.ui = CurMove} },
	{ MODKEY, BTN_MIDDLE, togglefloating, {0} },
	{ MODKEY, BTN_RIGHT,  moveresize,     {.ui = CurResize} },
};
